//Javascirpt

var moveUp = 1
